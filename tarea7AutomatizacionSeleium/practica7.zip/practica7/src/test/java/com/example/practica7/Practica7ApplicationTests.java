package com.example.practica7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
