package com.example.practica7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica7Application {

	public static void main(String[] args) {
		SpringApplication.run(Practica7Application.class, args);
	}

}
