package com.com470.coffeeMackerMockitoApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mockito1appApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mockito1appApplication.class, args);
	}

}
