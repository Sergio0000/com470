/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.com470.boleto.app.service;

import com.com470.boleto.app.controller.BoletoController;
import com.com470.boleto.app.dao.BoletoDao;
import com.com470.boleto.app.entities.Boleto;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import org.hamcrest.core.IsEqual;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
//import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.assertj.core.api.Assertions.assertThat;
import org.hamcrest.CoreMatchers;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author Hp
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class BoletoServiceTest {

    @Mock
    private BoletoDao boletoDao;
    @InjectMocks
    BoletoController boletoControler;
    @InjectMocks
    BoletoService boletoService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void createBoletotest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        Mockito.when(boletoService.createBoleto(boleto)).thenReturn(boleto);
        assertThat(boletoDao.save(boleto)).isEqualTo(boleto);
    }

    @Test

    public void getBoletoByIdTest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        Mockito.when(boletoDao.findOne(1)).thenReturn(boleto);
        assertThat(boletoService.getBoletoById(1)).isEqualTo(boleto);

    }

    @Test
    public void UpdateBoletoTest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        Mockito.when(boletoDao.findOne(1)).thenReturn(boleto);
        boleto.setEmail("torrezjorge@gmail.com");
        Mockito.when(boletoDao.save(boleto)).thenReturn(boleto);
        assertThat(boletoService.updateBoleto(1, "jorge.perez@gmail.com")).isEqualTo(boleto);
    }

    @Test
    public void getAllBoletosTest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");

        ArrayList<Boleto> boletos = new ArrayList<Boleto>();
   
        Mockito.when(boletoDao.findAll()).thenReturn(boletos);
        assertThat(boletoService.getAllBoletos()).isEqualTo(boletos);
    }

    @Test
    public void deleteBoletosTest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        boletoService.deleteBoleto(1);
        Mockito.verify(boletoDao).delete(1);
    }
}
