/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.com470.boleto.app.controller;

import com.com470.boleto.app.entities.Boleto;
import com.com470.boleto.app.service.BoletoService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author Hp
 */
public class BoletoControllerTest {

    @Mock
    private BoletoService boletoService;
    ;
   
    @InjectMocks
    BoletoController boletoController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

    }

    @Test
    public void createBoletoTest() {

        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        boletoController.createBoleto(boleto);
        Mockito.verify(boletoService).createBoleto(boleto);

    }

    @Test
    public void getBoletoByIdTest() {

        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        boletoController.getBoletoById(boleto.getBoletoId());
        Mockito.verify(boletoService).getBoletoById(boleto.getBoletoId());

    }

    @Test
    public void deleteBoletoTest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        boletoController.deleteBoleto(1);
        Mockito.verify(boletoService).deleteBoleto(1);
    }

    @Test
    public void getAllBoletosTest() {
        ArrayList<Boleto> boletos = new ArrayList<Boleto>();
        boletos.add(new Boleto());
        boletos.add(new Boleto());
        boletos.add(new Boleto());
        boletoController.getAllBoletos();
        Mockito.verify(boletoService).getAllBoletos();
    }

    @Test
    public void updateBoletoTest() {
        Boleto boleto = new Boleto();
        boleto.setBoletoId(1);
        boleto.setNombreDelPasajero("Jorge Torrez");
        boleto.setSalida("Sucre");
        boleto.setDestino("Santa Cruz");
        boleto.setFecha(new Date());
        boleto.setEmail("jorgetorrez@gmail.com");
        boletoController.updateBoleto(boleto.getBoletoId(), boleto.getEmail());
        Mockito.verify(boletoService).updateBoleto(boleto.getBoletoId(), boleto.getEmail());
    }

}
